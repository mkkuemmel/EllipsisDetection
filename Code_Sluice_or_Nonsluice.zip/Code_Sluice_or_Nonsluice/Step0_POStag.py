#import necessary libraries
import pandas as pd
import nltk
from treetagger import TreeTagger
#set path for treetagger
tt = TreeTagger(path_to_treetagger='/home/miriam/Downloads/treetagger/', language='german') #change path!

#import csv file as dataframe
whfinals_df = pd.read_csv('first_corpus.csv', header=None, sep=';')

#check progress of tagging with index i
i=0
#for every row in DF
for index, row in whfinals_df.iloc[1:].iterrows():

	hit = row[3]
	context_before=row[2]

	#POS-tag every occurence in column 'hit' and 'context before'
	tagged_hit = tt.tag(hit)
	tagged_context_before = tt.tag(context_before)
	row[13]=tagged_hit			   			 #insert tagged material in matrix
	row[14]=tagged_context_before
	


#write output in new csv
whfinals_df.to_csv('first_corpus_POStagged.csv', sep=';', header=None, index=False)