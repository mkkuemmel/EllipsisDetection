# -*- coding: utf-8 -*-

#for handling csv data, regex usage, plotting data
import pandas as pd, re, matplotlib.pyplot as plt,seaborn as sns 
from sklearn.metrics import confusion_matrix #for visualization
from ast import literal_eval #convert strings to lists

from Step2_data_investigation import list_woAZ, licensing_verbs #list of woa-z]+, list of QEV
from precrec import precision_and_recall #measures for precision, recall and F1-score

#read in the csv-corpus as a dataframe (pandas data format)
whfinals_df = pd.read_csv('output/whfinals_corpus.csv', header= None,encoding='utf8', sep=';')

#converts column POS-tagged Hit from string into list
whfinals_df.iloc[1:,13] = whfinals_df.iloc[1:,13].apply(literal_eval)


#frozen expressions:
#wer weiß w, Gott weiß w, weiß Gott w, ganz gleich w, egal w, dann und wann, gleichgültig w
#weiß der Teufel w, der Teufel weiß w, ganz gleich w, Wunder weiß w, gewusst wie, weiß der Himmel w, 
#so gut wie, was weiß ich w
frozen_expressions = ('wer weiß\,?\s?(\w*)? w[a-zäöü]+( viel(e?))?( und\s?(\w*)? w[a-zäöü]+)?\.',\
                      'gott weiß\,?\s?(\w*)? w[a-zäöü]+( viel(e?))?( und\s?(\w*)? w[a-zäöü]+)?\.',\
                      'weiß gott\,?\s?(\w*)? w[a-zäöü]+( viel(e?))?( und\s?(\w*)? w[a-zäöü]+)?\.',\
                      'egal\,?\s?(\w*)? w[a-zäöü]+( viel(e?))?( und\s?(\w*)? w[a-zäöü]+)?\.',\
                      'dann und wann',\
					  'gleichgültig\,?\s?(\w*)? w[a-zäöü]+( viel(e?))?( und\s?(\w*)? w[a-zäöü]+)?\.',\
                      'weiß der teufel\,?\s?(\w*)? w[a-zäöü]+( viel(e?))?( und\s?(\w*)? w[a-zäöü]+)?\.',\
                      'der teufel weiß\,?\s?(\w*)? w[a-zäöü]+( viel(e?))?( und\s?(\w*)? w[a-zäöü]+)?\.',\
                      '(ganz)? gleich\,?\s?(\w*)? w[a-zäöü]+( viel(e?))?( und\s?(\w*)? w[a-zäöü]+)?\.',\
                      'wunder weiß\,?\s?(\w*)? w[a-zäöü]+( viel(e?))?( und\s?(\w*)? w[a-zäöü]+)?\.',\
					  'gewu[sß]+t wie\.',\
                      'weiß der himmel\,?\s?(\w*)? w[a-zäöü]+( viel(e?))?( und\s?(\w*)? w[a-zäöü]+)?\.',\
					  'so gut wie\.',\
                      'was weiß ich\,?\s?(\w*)? w[a-zäöü]+( viel(e?))?( und\s?(\w*)? w[a-zäöü]+)?\.')

#interjections:
#ach was, na sowas, und wie
interjections = ('[^A-Za-z]?ach\,? w[a-z]+\.', 'na so ?was\.', '^und wie\.', '\, und wie\.')

#hint for 'was' to be a pronoun: so was (short for 'so etwas')
hint_for_indefpron = ('so was\.', '\, so was\.')



''' Functions to calculate the performance of the respective rules'''
def check_predictions_nonsluice(which_rule):
	if which_rule.row[6]=='n':
		which_rule.correct+=1
	if which_rule.row[6]=='y':
		which_rule.false+=1
		which_rule.falselist.append(which_rule.row[3])
		
def check_predictions_sluice(which_rule):
   #check if prediction was correct
	if which_rule.row[6]=='y': 
		which_rule.correct+=1
	if which_rule.row[6]=='n':
		which_rule.false+=1
		which_rule.falselist.append(which_rule.row[3])  		
                    
def summary_predictions(which_rule):    
	#list false predictions and number of correct ones
	print(which_rule.false,'false prediction(s) by',which_rule.__name__+':') 
	for element in which_rule.falselist:
		print ('-',element)
	print(which_rule.correct,'correct prediction(s).\n')
		
def instant_vars(which_rule):
    which_rule.false=0
    which_rule.correct=0
    which_rule.falselist=[] 
	
###############################################################################################################	
###############################################################################################################
################################################## THE RULES ##################################################
###############################################################################################################
###############################################################################################################


'''1. Checks if a fixed expression is in the sentence'''
'''If yes, predicted as non-sluice'''
###################################################################################################
#function to determine if non-sluice is in row
def nonsluice_finder(which_non, input_row):
	hit=str(input_row[3])
	for non in which_non:
        #apply RE on hit-column, lower space it
		non_detect = re.search(non, hit.lower())
        
        #returns True if RE is found in sentence
		if non_detect:        
			return True

def regexes(which_df):
	froz=0
	interj=0
	indefpron=0
	instant_vars(regexes)
    #if the program finds one of the regex in the line it predicts that the line is a non-sluice
	for index, regexes.row in which_df.iloc[1:].iterrows():
		if regexes.row[18] != 'y' and regexes.row[18] != 'n':   	#only treat sentences that haven't been treated yet
			if nonsluice_finder(frozen_expressions,regexes.row): 	#find frozen expressions
				regexes.row[18]='n'
				froz+=1
				check_predictions_nonsluice(regexes)	#check if the predictions were correct
                    
			if nonsluice_finder(interjections,regexes.row):    #find interjections
				regexes.row[18]='n'
				interj+=1         
				check_predictions_nonsluice(regexes)


			if nonsluice_finder(hint_for_indefpron,regexes.row):   #find some indefinite pronouns
				regexes.row[18]='n'
				indefpron+=1
				check_predictions_nonsluice(regexes)

	print(str(interj),'found as interjections,\n'+str(froz),'found as frozen expressions,\n'+\
	   str(indefpron),'found as indefinite pronoun\n')
	summary_predictions(regexes)  #summarize false and correct predictions
###################################################################################################


'''2. POS: Utilize the POS we can'''
###################################################################################################
def POS(which_df):
    instant_vars(POS)
    for POS.index, POS.row in which_df.iloc[1:].iterrows():
        if POS.row[18] != 'y' and POS.row[18] != 'n':
            
            if POS.row[5]=='was':   #check if 'was' is POS-tagged as 'PIS'
                if POS.row[15]=='PIS':
                    POS.row[18]='n'     #if so, predict as non-sluice
                    check_predictions_nonsluice(POS)                    
                else:
                    POS.row[18]='y'    #if 'was' is tagged as anything else, predict as sluice
                    check_predictions_sluice(POS)
            
            if POS.row[5]=='welche':   #check if 'welche' is POS-tagged as 'PIS'
                if POS.row[15]=='PIS':
                    POS.row[18]='n'    #if so, predict as non-sluice
                    check_predictions_nonsluice(POS)                
                else:
                    POS.row[18]='y'    #if 'welche' is tagged as anything else, predict as sluice
                    check_predictions_sluice(POS)
                    
    summary_predictions(POS)				   
    
###################################################################################################


'''3. Check if the wh-phrase begins with wo (worüber, worauf,...) or is a version of why'''
'''If yes, predicted as sluice'''
###################################################################################################
def woAZ_why(which_df):
    instant_vars(woAZ_why)
    for woAZ_why.index, woAZ_why.row in which_df.iloc[1:].iterrows():
        if woAZ_why.row[18] != 'y' and woAZ_why.row[18] != 'n':  
            
            #check if whphrase is a wo[a-z]+ or a version of 'why'
            if woAZ_why.row[5] in list_woAZ or woAZ_why.row[5] in ['warum','weshalb','wieso', 'weswegen']:   
                woAZ_why.row[18]='y'    #if so, predict as sluice
                check_predictions_sluice(woAZ_why)
				
    summary_predictions(woAZ_why)

###################################################################################################


'''4. Checks if wh-phrase is directly preceded by a preposition'''
'''If yes, predicted as sluice'''
###################################################################################################
def prep_check(which_df):
    instant_vars(prep_check)
    tags_prepositions=['APPR','APPRART'] #tags that prepositions can have
    for prep_check.index, prep_check.row in which_df.iloc[1:].iterrows():
        if prep_check.row[18] != 'y' and prep_check.row[18] != 'n':       
            tagged=list(prep_check.row[13])
            mini_list=tagged[-3] #access third last element of sentence
            if mini_list[1] in tags_prepositions: #see if the third last element is a preposition
                prep_check.row[18]='y'#if it is a preposition, tag sentence as sluice
                check_predictions_sluice(prep_check)  #check if prediction was correct
                    
    summary_predictions(prep_check)
    
###################################################################################################


'''5. Check if the last verbal element is in the list of licensing verbs'''
'''If yes, predicted as sluice'''
###################################################################################################
def embedding(which_df):
    instant_vars(embedding)
    for embedding.index, embedding.row in which_df.iloc[1:].iterrows():
        if embedding.row[18] != 'y' and embedding.row[18] != 'n':
            
            #check if the last verb is a QEV
            if embedding.row[16] in licensing_verbs:  
                embedding.row[18]='y'     #if so, predict as sluice
                check_predictions_sluice(embedding)
                
    summary_predictions(embedding)
    
###################################################################################################


'''6. Check if the wh-phrase can be a pronoun'''
'''If no, predicted as sluice'''
###################################################################################################
def not_pronoun(which_df):
    instant_vars(not_pronoun) 
    for not_pronoun.index, not_pronoun.row in which_df.iloc[1:].iterrows():
        if not_pronoun.row[18] != 'y' and not_pronoun.row[18] != 'n':
            #these wh-words cannot be pronouns:
            cant_be_pron=['wieso', 'weshalb', 'warum', 'weswegen', 'wann', 'wie', 'wo']
            if not_pronoun.row[5] in cant_be_pron:  #check if wh-word is a not-pronoun
                not_pronoun.row[18] = 'y'   #if so, predict as sluice
                check_predictions_sluice(not_pronoun)
                
    summary_predictions(not_pronoun)
        
###################################################################################################


'''7. Check if one of the last elements in a sentence is punctuation'''
'''If yes, predicted as sluice'''
###################################################################################################
def punctuation(which_df):
    instant_vars(punctuation)
    for punctuation.index, punctuation.row in which_df.iloc[1:].iterrows():
        
        if punctuation.row[18] != 'y' and punctuation.row[18] != 'n': 
            punctuation.tagged_hit=punctuation.row[13]
            #list of punctuation
            punctuation_marks=[',', ';', '-']
            try: #try to make a list of the last elements before the wh-word
                last_elements=[punctuation.tagged_hit[-5],punctuation.tagged_hit[-4],\
							    punctuation.tagged_hit[-3]]
            except:
                punctuation.row[18]='n'     #if sentence too short, predict as non-sluice
                check_predictions_nonsluice(punctuation) #check if prediction was correct               
                    
            #check if there's a punct mark among the last elements        
            for element in last_elements:   
                if element[0] in punctuation_marks:
                        punctuation.row[18]='y'     #if so, predict as sluice
                        check_predictions_sluice(punctuation)   #check if prediction was correct
                        break     #stop as soon as one punct mark is found
                    
    summary_predictions(punctuation)
    
###################################################################################################

                    
'''8. Check if there is a verb in the Hit or the ContextBefore'''
'''If not, predicted as non-sluice'''
###################################################################################################
def verb_search(which_df):
    instant_vars(verb_search)
    for verb_search.index, verb_search.row in which_df.iloc[1:].iterrows():
        if verb_search.row[18] != 'y' and verb_search.row[18] != 'n':
            if verb_search.row[16]=='<none>':   #check if there is a verb in this or previous sentence
                verb_search.row[18]='n'     #if there's no verb, predict as non-sluice
                check_predictions_nonsluice(verb_search)

    summary_predictions(verb_search)
    
###################################################################################################


'''9. Check sentence length'''
'''If shorter than 3, predicted as non-sluice'''
###################################################################################################
def sent_length(which_df):
    instant_vars(sent_length)
    for sent_length.index, sent_length.row in which_df.iloc[1:].iterrows():
        if sent_length.row[18] != 'y' and sent_length.row[18] != 'n':
            if int(sent_length.row[12])<=2:     #check if sentence is 2 words or shorter
                sent_length.row[18]='n'     #if so, predict as non-sluice
                check_predictions_nonsluice(sent_length)
		
    summary_predictions(sent_length)
    
###################################################################################################
    

'''10: check negation'''
'''if negation particle in sight, predicted as sluice'''
###################################################################################################
def negation(which_df):
    instant_vars(negation)
    for negation.index, negation.row in which_df.iloc[1:].iterrows():
        
        if negation.row[18] != 'y' and negation.row[18] != 'n': 
            negation.tagged_hit=negation.row[13]

            try: #try to make a list of the last elements before the wh-word
                last_elements=[negation.tagged_hit[-6],negation.tagged_hit[-5],\
							   negation.tagged_hit[-4], negation.tagged_hit[-3]]
            except:
                pass
			
            for el in last_elements:
                if el[1] =='PTKNEG' : #check if one of those elements is a negation particle
                    negation.row[18]='y' #if so, predict as sluice
                    check_predictions_sluice(negation)

    summary_predictions(negation)				   

###################################################################################################


'''11. wissen'''
'''If the last verb is 'wissen', predicted as Sluice '''
###################################################################################################
def wissen(which_df):
    instant_vars(wissen)
    for wissen.index, wissen.row in which_df.iloc[1:].iterrows():
        if wissen.row[18] != 'y' and wissen.row[18] != 'n':
            if wissen.row[16]=='wissen':     #check if last verb is 'to know'
                wissen.row[18]='y'     #if so, predict as sluice
                check_predictions_sluice(wissen)
		
    summary_predictions(wissen)
    
###################################################################################################


'''12. wer_sein'''
'''If wh-word is 'wer' and the last verb is 'sein', predicted as Non-Sluice'''
###################################################################################################
def wer_sein(which_df):
    instant_vars(wer_sein)
    for wer_sein.index, wer_sein.row in which_df.iloc[1:].iterrows():
        if wer_sein.row[18] != 'y' and wer_sein.row[18] != 'n':
            if wer_sein.row[16] =='sein' and wer_sein.row[5]=='wer': #check if last verb is 'to be'
																		#and wh-phrase is 'who'
                wer_sein.row[18]='n'     #if so, predict as non-sluice
                check_predictions_nonsluice(wer_sein)
		
    summary_predictions(wer_sein)
    
###################################################################################################


'''13. Last step in algorithm: Everthing that has not been labelled must be a non-sluice'''
###################################################################################################
#check if every line has been labelled
def wrapup(which_df):
    unlabelled=0
    instant_vars(wrapup)
    for wrapup.index, wrapup.row in which_df.iloc[1:].iterrows():
        if wrapup.row[18] != 'y' and wrapup.row[18] != 'n':
            unlabelled+=1	#count sentences that could not be fetched by the algorithm
            wrapup.row[18]='n' 	#predict them as non-sluices
            check_predictions_nonsluice(wrapup)
       
    summary_predictions(wrapup)
###################################################################################################
    
	

###############################################################################################################	
###############################################################################################################
###################################### THE APPLICATION OF THE RULES ###########################################
###############################################################################################################
###############################################################################################################

# Good for wh-finals corpus: 1 12 4 8 10 2 3 7 6 9 5 11 13
# Good for second corpus: 1 2 12 4 11 8 9 6 3 5 7 10 13
print('PERFORMANCE OF THE RULES:')
print('_'*30,'\n\n')

#this is the order for the second corpus

#regexes(whfinals_df)#1
#POS(whfinals_df)#2
#wer_sein(whfinals_df)#12
#prep_check(whfinals_df)#4
#wissen(whfinals_df)#11
#verb_search(whfinals_df)#8
#sent_length(whfinals_df)#9
#not_pronoun(whfinals_df)#6
#woAZ_why(whfinals_df)#3
#embedding(whfinals_df)#5
#punctuation(whfinals_df)#7
#negation(whfinals_df)#10


#this is the order for the wh-finals/first corpus

regexes(whfinals_df)#1
wer_sein(whfinals_df)#12
prep_check(whfinals_df)#4
verb_search(whfinals_df)#8
negation(whfinals_df)#10
POS(whfinals_df)#2
woAZ_why(whfinals_df)#3
punctuation(whfinals_df)#7
not_pronoun(whfinals_df)#6
sent_length(whfinals_df)#9
embedding(whfinals_df)#5
wissen(whfinals_df)#11

#this step has to be last
wrapup(whfinals_df)#13

#calculate precision and recall
precision_and_recall(whfinals_df)


#instantiate heatmap for visualization of result
actual=whfinals_df.iloc[1:,6]
pred=whfinals_df.iloc[1:,18]
conf_mat = confusion_matrix(actual, pred)
fig, ax = plt.subplots(figsize=(5,5))
sns.heatmap(conf_mat, annot=True, fmt='d',
            xticklabels=['n', 'y'], yticklabels=['n', 'y'])
plt.ylabel('Actual')
plt.xlabel('Predicted')
plt.show()