# -*- coding: utf-8 -*-

#pd for handling csv data, re for regex usage, plt for plotting data
import pandas as pd, re, matplotlib.pyplot as plt

#convert strings to lists
from ast import literal_eval

#read in the csv-corpus as a dataframe (pandas data format)
whfinals_df = pd.read_csv('output/whfinals_corpus.csv', header= None,encoding='utf8', sep=';')



###############################################################################################################	
###############################################################################################################
############################################## THE FUNCTIONS ##################################################
###############################################################################################################
###############################################################################################################

''''I. distribution function: counts and plots how often a certain wh-phrase occurs'''
###################################################################################################
def distribution_funct(which_df):
    global list_woAZ
    list_woAZ=[]    #list of wh-phrases that start with 'wo'
    
    #set up dictionary for wh-phrases
    distribution_whphrases={}
    
    #access every single row
    for index, row in which_df.iloc[1:].iterrows():

        #count number of occurences for every wh-phrase
    	if row[5] not in distribution_whphrases.keys():    
    		distribution_whphrases[row[5]] = 1
    	else:
    		distribution_whphrases[row[5]] += 1            
    
    #group wo[a-z] together to make a sensible pie chart
    distribution_whphrases['wo[a-z]+']=0
    for key, val in distribution_whphrases.items():
        if re.search('wo[a-z]+', key):
            distribution_whphrases['wo[a-z]+'] += val
            distribution_whphrases[key] = 0
            list_woAZ.append(key)
            
    #delete the single wo[a-z] out of the dict 
    for key in list(distribution_whphrases.keys()):
        if re.search('wo[a-z]+', key):
            del distribution_whphrases[key]  
        

    #plot wh-phrase distribution
    print('\n\n\t\tDistribution of wh-phrases')
    labels=distribution_whphrases.keys()
    sizes=list(distribution_whphrases.values())
    plt.pie(sizes,labels=labels, startangle=30,labeldistance=1.05)
    plt.axis('equal')
    plt.show()
	
###################################################################################################


'''II. investigation'''
'''investigates and plots the HAND-annotated meta-data'''
'''sluice yes or no, merger or sprouting, which non-sluice, clause negated?, embedding verbs, build list of
    all wh-phrases'''
##################################################################################################
def investigation(which_df):
    global list_of_whphrases
    list_of_whphrases=[]
    global whfinalscounter
    whfinalscounter = 0
    merger=0
    sprouting=0
    yescounter=0
    global nocounter
    nocounter=0
    annot_elision=0			
    annot_interjection=0
    annot_froz=0
    annot_indefpron=0
    negatedY=0
    negatedN=0
    negatedYsluice=0
    negatedNsluice=0
    embedverbs={}
    position_verbs={}
    unembedded=0
    
    for index, row in which_df.iloc[1:].iterrows():
	#count all rows -> all wh-finals
        whfinalscounter += 1
        
        if row[6]=='y':
            
            # a) count all sluices
            yescounter+=1   
            
            # b) check if merger or sprouting
            if row[10]=='m' or row[10]=='m, bef':   
                merger+=1
            if 's' in row[10]:
                sprouting +=1
                
            # c) check if clause is negated
            if row[11]=='n':        
                negatedN += 1
                negatedNsluice+=1
            else:
                negatedY += 1
                negatedYsluice+=1

            # d) count embedding verbs
            if row[8] not in embedverbs.keys(): 
                embedverbs[row[8]]=1
            else:
                embedverbs[row[8]]+=1
            
            # d) check how many unembedded sluices
            if row[8]=='<unembedded>':      
                unembedded +=1
            
            # d) check position of embedding verb
            if row[9] not in position_verbs.keys(): 
                position_verbs[row[9]]=1
            else:
                position_verbs[row[9]]+=1
        
        else: 
            #count all non-sluices
            nocounter+=1

            # c) check if clause is negated
            if row[11]=='n':        
                negatedN += 1
            else:
                negatedY += 1			
            
            # e) check what non-sluice they are
            if row[7] =='elision':  
                annot_elision+=1
            if row[7]=='interjection':
                annot_interjection+=1
            if row[7]=='frozen expression':
                annot_froz+=1
            if row[7]=='indefinite pronoun':
                annot_indefpron+=1		
	
        # f) build a list of all wh-phrases that occur in the corpus
        if row[5] not in list_of_whphrases: 
            list_of_whphrases.append(row[5])
      
    print('\n\n\n\n\t\tInvestigation of the corpus\n\n')
    # concerning a): plot Sluice yes/no
    print('The corpus contains',whfinalscounter,'sentences.\nSluices:', \
          yescounter,', Non-Sluices:',nocounter,'\n\n')
    percentage_yes = yescounter/whfinalscounter
    percentage_no = nocounter/whfinalscounter
    colors = ['g','limegreen']
    labels1='Sluice','Non-Sluice'
    sizes1=[percentage_yes, percentage_no]
    plt.pie(sizes1,labels = labels1, autopct='%1.1f%%', colors=colors, startangle = 140, labeldistance = 1.05)
    plt.axis('equal')
    plt.show()
    
    # concerning b): plot merger/sprouting
    percentage_merg = merger/yescounter
    percentage_sprout = sprouting/yescounter
    colors = ['lightsteelblue','cornflowerblue']
    labels3='Merger','Sprouting'
    sizes3=[percentage_merg, percentage_sprout]
    plt.pie(sizes3,labels = labels3, autopct='%1.1f%%', colors=colors, startangle = 140, labeldistance = 1.05)
    plt.axis('equal')
    plt.show() 

    # concerning c) print how many are negated
    proportion_negated= round((negatedYsluice/yescounter),2)*100
    proportion_negated_all = round((negatedY/whfinalscounter),2)*100
	
    print(negatedYsluice,'of the',yescounter,'sluices are negated. ('+str(proportion_negated)+'%)\n')
    print(negatedY,'of all',whfinalscounter,'wh-final sentences are negated. ('+str(proportion_negated_all)+'%)\n')

    # concerning d) print and plot results of embedding verbs
    labels=embedverbs.keys()
    sizes=list(embedverbs.values())
    plt.pie(sizes,labels=labels, startangle=30,labeldistance=1.05)
    plt.axis('equal')
    plt.show()
	
    #which embedding verbs are the most frequent
    print('MOST FREQUENT OUT OF',len(embedverbs.keys()),'EMBEDDING VERBS IN',yescounter,'SLUICES') 
    for key, val in embedverbs.items():
        if int(val) > 8:
            perc=int(val)/int(yescounter)
            print(str(key)+':',str((round(perc,4))*100)+'%')
    
    print('\nNUMBER OF UNEMBEDDED SLUICES')  #proportion of unembedded sluices
    proportion_unembedded=round((unembedded/yescounter),3)*100
    print("Total:",str(unembedded)+", Percentage:",str(proportion_unembedded)+'%\n')


    print('\n')
    print('THESE ARE THE POSITIONS OF THE EMBEDDING VERBS') #position of the embedding verb
    for key, val in position_verbs.items():
        proportion_position_of_verbs=round(int(val)/int(yescounter),4)*100
        print('Position',str(key)+':',str(proportion_position_of_verbs)+'%')
    print('\n')
    
    # concerning e): print and plot results which Non-Sluice
    print('Out of the',nocounter,'nonsluices, there are\n'+str(annot_elision),'annotated as elision\n'+str(annot_interjection),'annotated as interjection\n'+\
          str(annot_froz),'annotated as frozen expression\n'+str(annot_indefpron),'annotated as indefinite pronoun.\n\n')
    
    perc_elision = annot_elision/nocounter
    perc_interjection = annot_interjection/nocounter
    perc_froz = annot_froz/nocounter
    perc_indefpron = annot_indefpron/nocounter
    labels2='elision','interjection','frozen expression', 'indefinite pronoun'
    sizes2=[perc_elision, perc_interjection, perc_froz, perc_indefpron]
    plt.pie(sizes2,labels = labels2, autopct='%1.1f%%', startangle = 140, labeldistance = 1.05)
    plt.axis('equal')
    plt.show()
    
###################################################################################################    


'''III. count_tags: investigating which POS the wh-phrases have'''
###################################################################################################
#for counting POS-tag occurrences
def count_tags (which_df):
    pos_dict= {}
    for index, row in which_df.iloc[1:].iterrows():
        if row[15] not in pos_dict.keys():
            pos_dict[row[15]] = 1
        else:
            pos_dict[row[15]] += 1
            
    #converts column POS-tagged Hit from strings into list!
    which_df.iloc[1:,13] = which_df.iloc[1:,13].apply(literal_eval)
    
    #print result of counting the POS-tags
    print('THIS IS HOW OFTEN THE POS-TAGS OCCUR')
    for key, val in pos_dict.items():
        proportion_tags= round(val/len(pos_dict.keys()),2)
        print(key,'occurs', val, 'times.', '('+str(proportion_tags)+'%)')

###################################################################################################


'''IV. create_summary_tuples: 
    builds one tuple for every sentence in the corpus: (wh-phrase, Sluice Y/N, POS of whphrase)'''
################################################################################################### 
def create_summary_tuples (which_df):
    global list_of_summary_tuples
    list_of_summary_tuples=[]

    for index, row in which_df.iloc[1:].iterrows():
        whphrase=row[5]
        sluiceYN=row[6]
        pos_wphrase=row[15]

        summary_tuple=(whphrase,sluiceYN,pos_wphrase)        #create a tuple for every row: which whphrase, 
                                                                #is it a sluice, what's the POS
        list_of_summary_tuples.append(summary_tuple)

###################################################################################################


'''V. compare_pos: compares the POS of the specific wh-phrase'''
###################################################################################################
#compare POS of sluice/nosluice
def compare_pos (which_word):
    pos_tup_sluice=[]
    pos_tup_no_sluice=[]
    whphrase_counter=0
    for sum_tup in list_of_summary_tuples:

        if sum_tup[0] == which_word:
            whphrase_counter += 1   #count how often specific wh-phrase occurs
            if sum_tup[1]=='y':
                pos_tup_sluice.append(sum_tup[2])   #all the sluices in one dict
            else:
                pos_tup_no_sluice.append(sum_tup[2])    #all the non-sluices in other dict

    pos_dict_sluice={}
    pos_dict_no_sluice={}			
    end_result={}
	
    for item in pos_tup_sluice:
        if item not in pos_dict_sluice.keys():
            pos_dict_sluice[item]=1
        else:
            pos_dict_sluice[item]+=1
		
    for item in pos_tup_no_sluice:
        if item not in pos_dict_no_sluice.keys():
            pos_dict_no_sluice[item]=1
        else:
            pos_dict_no_sluice[item]+=1
	
	#creates readable table
    end_result[which_word]=pos_dict_no_sluice,pos_dict_sluice
    print (whphrase_counter, ' '*(10-len(str(whphrase_counter))),'|',which_word, ' '*(9-len(which_word)), '|', \
           pos_dict_no_sluice,' '*(36-len(str(pos_dict_no_sluice))), '|', pos_dict_sluice)
    pos_dict_sluice={}
    pos_dict_no_sluice={}
    whphrase_counter=0	
###################################################################################################



'''VI. verb_list: List of QEV + function to add all the licensing verbs in the corpus'''
###################################################################################################   
licensing_verbs = ['wissen', 'erinnern', 'vergessen', 'ankündigen', 'bemerken', 'lernen', 'herausfinden', 
                    'entdecken', 'erzählen', 'zeigen', 'aufzeigen', 'anzeigen', 'informieren', 'preisgeben', 
                    'entscheiden', 'festlegen', 'spezifizieren', 'einigen', 'kontrollieren', 'erraten', 
                    'vorhersagen', 'wetten', 'schätzen', 'keine Ahnung haben', 'sicher sein', 'unsicher sein', 
                    'fragen', 'untersuchen', 'interessieren', 'nachfragen', 'herausbekommen', 'angeben', 
                    'begründen', 'erklären', 'schildern', 'stellen', 'stehen', 'bekanntgeben', 'zeigen'
                    'raten', 'entscheiden', 'herausbekommen', 'merken', 'lauten']

def verb_list (which_df, which_list):
    i=0
    for index, row in which_df.iloc[1:].iterrows():
        embed_verb=row[8]
        if embed_verb not in which_list and '<' not in str(embed_verb):
            which_list.append(embed_verb)       #extend verblist with verbs occuring in the corpus
            i+=1
    print(i,'verbs added to the list of QEV (question embedding verbs).\n\n\n')


###############################################################################################################	
###############################################################################################################
#################################### THE APPLICATION OF THE FUNCTIONS #########################################
###############################################################################################################
###############################################################################################################

distribution_funct(whfinals_df)
investigation(whfinals_df)
count_tags(whfinals_df)
create_summary_tuples(whfinals_df)

'''VII pos_table: creates table of POS in Sluice/Non-Sluice'''
###################################################################################################
def pos_table():
    print('\n\n')	
    print('how often   | wh-phrase  | Non-Sluice',' '*25,' | Sluice')
    print('-'*95)
    for whphrase in list_of_whphrases:
        compare_pos(whphrase)
    print('\n\n')

pos_table()
######################################################################################################
verb_list(whfinals_df,licensing_verbs)