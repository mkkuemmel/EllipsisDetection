# -*- coding: utf-8 -*-

stopwords = open('corpora/stopwords.txt', 'r',encoding="utf-8")
german_stopwords=[]



for line in stopwords:
	line=line.rstrip('\n')
	german_stopwords.append(line)