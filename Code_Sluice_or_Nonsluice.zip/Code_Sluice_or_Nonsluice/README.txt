#readme file for master's thesis by Miriam Kuemmel:
#Ellipsis Detection: Machine Learning vs. Rule-Based Document Classification


The code was developed using Anaconda 1.9.4 (2016), Spyder 3.3.2; all packages and libraries
used in the thesis (except for TreeTagger) are available through it.
Download available here: https://repo.continuum.io/.

Step0_POStag.py: Does NOT need to be executed. It is a script to POS-tag the corpora, but
					as the Python-TreeTagger interaction is difficult and instable, the corpora 
					were attached to the thesis in their tagged version already.

Step1_computational_annotation.py: In line 8, the path to the desired corpus must be given.
									Produces whfinals_corpus.csv.

Step2_data_investigation.py: Imports whfinals_corpus.csv; therefore is dependent on Step1.

Step3_rule_based_doc_class.py: Also imports whfinals_corpus.csv; therefore is dependent on Step1.
								From line 375 on, the order of the rules can be changed and adapted to 
								whatever corpus is processed.
								Best order for first and second corpus is given in 
								the script.
				
Step3_ML_doc_class.py: In line 17, the path to the desired corpus must be given.
						To try out the impact of excluding stopwords from the model, line 46 must be changed to:
						
						tfidf = TfidfVectorizer(sublinear_tf=True, min_df=3, norm='l2', encoding='utf-8', ngram_range=(1, 2),stop_words=german_stopwords)

						Run process_stopwords.py before trying this.
						
process_stopwords.py: Script to turn stopwords.txt into a list of stopwords. Must be executed before executing 
						Step3_ML_doc_class.py.

precrec.py: Script to calculate precision, recall and F1-score of the rule-based algorithm.
