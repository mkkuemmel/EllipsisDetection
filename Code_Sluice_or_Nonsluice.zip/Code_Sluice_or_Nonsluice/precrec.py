# -*- coding: utf-8 -*-
'''function to calculate precision, recall and f1-score in rule-based doc classification'''

def precision_and_recall (which_df):
    tn = 0
    fn = 0
    fp = 0
    tp = 0
    fp_list=[]
    fn_list=[]
    for index, row in which_df.iloc[1:].iterrows():
        actual=row[6]
        predicted=row[18]
        
        if actual == "n":
            if predicted == "n":
                tn +=1
            if predicted == "y":
                fp += 1
                fp_list.append(row[3])
                
        
        if actual == "y":
            if predicted == "n":
                fn += 1
                fn_list.append(row[3])
            if predicted == "y":
                tp += 1
    
    precision = (tp)/(tp+fp)
    recall = (tp)/(tp+fn)
    f1_score = 2* ((precision*recall)/(precision+recall))
    
    print("Precision: ",round(precision,4))
    print("Recall: ",round(recall,4))
    print("F1-Score: ",round(f1_score,4))
    
    
    print('\n\nClassified as sluice, but actually a non-sluice (false positives):',len(fp_list),'\n')
    for item in fp_list:
        print('-',item)
    print('\n\nClassified as non-sluice, but actually a sluice (false negatives):', len(fn_list),'\n')
    for item in fn_list:
        print('-',item)
    
            