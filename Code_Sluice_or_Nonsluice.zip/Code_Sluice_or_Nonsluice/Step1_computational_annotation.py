
#convert strings to lists
from ast import literal_eval
#import necessary libraries
import pandas as pd

#import csv file as dataframe
whfinals_df = pd.read_csv('corpora/first_corpus_POStagged.csv', header=None, sep=';') #change path if necessary

#verbal tags
finite_verbal_tags = ['VVFIN', 'VVIMP', 'VVINF', 'VVIZU', 'VVPP', 'VAFIN', \
                      'VMINF', 'VMFIN', 'VMPP']


#converts column POS-tagged Hit and context_before from strings to list
whfinals_df.iloc[1:,13] = whfinals_df.iloc[1:,13].apply(literal_eval)
whfinals_df.iloc[1:,14] = whfinals_df.iloc[1:,14].apply(literal_eval)


#for every row in DF
for index, row in whfinals_df.iloc[1:].iterrows():
	hit = row[3]
	context_before=row[2]
	tagged_hit=row[13]
	tuple_whphrase = tagged_hit[-2]           #access tagged wh-phrase
	tagged_context_before=row[14]

		
	'''I'''
	row[12]=len(hit.split())		#measure length of sentence and insert in matrix
		
	'''II'''
	wh_phrase_itself = tuple_whphrase[2]
	row[5] = wh_phrase_itself				#insert wh-phrase itself in matrix
		
	'''III'''
	pos_whphrase = tuple_whphrase[1]
	row[15] = pos_whphrase				#insert POS of wh-phrase in matrix


	'''IV'''		
	#what's the last verbal element? 
	for mini_list in reversed(tagged_hit):    #loop through tagged hit reversely
		if mini_list[1] in finite_verbal_tags:
			row[16] = mini_list[2]         	 #insert last verbal element before wh-phrase in matrix
			break
		#if no verb found in hit, check context before
		if mini_list[1] not in finite_verbal_tags:  	 
			for context_mini_list in reversed(tagged_context_before):
				if context_mini_list[1] in finite_verbal_tags:
					row[16] = context_mini_list[2]
					break
				if context_mini_list[1] not in finite_verbal_tags:
					if 'keine ahnung' in hit.lower():	#exception: elided 'keine Ahnung haben' used as verb in hit
						row[16] = 'keine Ahnung haben'
					else:
						row[16] = '<none>'				#if no verb found in either sentence, insert <none>

			
	'''V'''
	#is the last verbal element also the embedding verb?
	if row[6] == 'y':   
		if str(row[16]) in str(row[8]):   #check if embedding verb and last verbal element are the same
			row[17] ='y'
		else:
			row[17] ='n'			
	if row[6] == 'n':         #if it's a Non-Sluice, there's no embedding verb --> insert 'NA'
		row[17] = 'NA'

	
#turn wh-finals corpus in CSV-file
whfinals_df.to_csv('output/whfinals_corpus.csv', sep=';', header=None, index=False)	